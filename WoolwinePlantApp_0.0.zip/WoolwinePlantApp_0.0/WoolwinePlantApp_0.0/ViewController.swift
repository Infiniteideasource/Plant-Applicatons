//
//  ViewController.swift
//  WoolwinePlantApp_0.0
//
//  Created by Arun Sreekumar on 25/03/17.
//  Copyright © 2017 Apple Inc. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate {
    
    
    //MARK: Properties
    @IBOutlet weak var equipmentNameLabel: UILabel!
    @IBOutlet weak var equipmentNameTextField: UITextField!
    @IBOutlet weak var equipmentPickerView: UIPickerView!
    
    @IBOutlet weak var dataSourceLabel: UILabel!
    @IBOutlet weak var dataSourceTextField: UITextField!
    @IBOutlet weak var dataSourcePickerView: UIPickerView!
    
    @IBOutlet weak var parameterButton: UIButton!
    
    
    var equipmentsArray = [String]()
    var dataSourceArray = [String]()
    var eqmntsObjArray = [Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Set up the equipments array
        setEquipmentsArray()
                
        self.equipmentPickerView.dataSource = self
        self.equipmentPickerView.delegate = self
        self.equipmentNameTextField.delegate = self
        
        self.dataSourcePickerView.dataSource = self
        self.dataSourcePickerView.delegate = self
        self.dataSourceTextField.delegate = self
        
        //Hide Secondary view
        self.dataSourcePickerView.isHidden = true
        self.dataSourceLabel.isHidden = true
        self.dataSourceTextField.isHidden = true
    }
    
    //MARK: UIPickerViewDataSource methods
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        var rowCount = 0
        
        if pickerView == equipmentPickerView {
            rowCount = equipmentsArray.count
        }
        
        if pickerView == dataSourcePickerView {
            rowCount = dataSourceArray.count
        }
        
        return rowCount
    }
    
    //MARK: UIPickerViewDelegate methods
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        //resign the first responder status for text field
        self.view.endEditing(true)
        
        if pickerView == equipmentPickerView {
            return equipmentsArray[row]
        }
        if pickerView == dataSourcePickerView {
            return dataSourceArray[row]
        }
        return ""
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerView == equipmentPickerView {
            
            self.equipmentNameTextField.text = equipmentsArray[row]
            
            //Hide the picker view after setting textfield
            self.equipmentPickerView.isHidden = true
            
            //Set up dataSourceArray for equipment selected
            let equipmentSelected = equipmentsArray[row]
            setDataSourceArray(for: equipmentSelected)
        
            //Reload secondary picker view
            dataSourcePickerView.reloadAllComponents()
            
            //Unhide the secondary views
            self.dataSourcePickerView.isHidden = false
            self.dataSourceLabel.isHidden = false
            self.dataSourceTextField.isHidden = false
        }
        
        if pickerView == dataSourcePickerView {
            self.dataSourceTextField.text = dataSourceArray[row]
            self.dataSourcePickerView.isHidden = true
        }
    }
    
    //MARK: UITextFiledDelegate methods
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == self.equipmentNameTextField {
            
            //Clear the dataSourceArray 
            if dataSourceArray.count > 0 {
                dataSourceArray.removeAll()
            }
            
            //Clear Data Source Text Field
            if dataSourceTextField.text != nil {
                dataSourceTextField.text?.removeAll()
            }
            
            //Hide Secondary view
            self.dataSourcePickerView.isHidden = true
            self.dataSourceLabel.isHidden = true
            self.dataSourceTextField.isHidden = true
            
            //Unhide the picker view when user clicks text field
            self.equipmentPickerView.isHidden = false
            
        }
        
        if textField == self.dataSourceTextField {
            
            //Unhide the picker view when user clicks the text field
            self.dataSourcePickerView.isHidden = false
        }
        
        //Hide the keyboard
        textField.endEditing(true)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK: Actions
    
    @IBAction func readParameters(_ sender: UIButton) {
        print("Reading parameters")
    }
    
    //MARK: Private Methods
    func setDataSourceArray(for equipment: String) {
        
        //Clear the elements in dataSourceArray first
        dataSourceArray.removeAll()
        
        for (_,object) in eqmntsObjArray.enumerated() {
            
            if let eqDict = object as? [String: Any], let eqName = eqDict["equipmentName"] as? String {
                
                if eqName == equipment {
                    
                    if let dataSrceArray = eqDict["dataSources"] as? [Any] {
                        
                        for (_,dObject) in dataSrceArray.enumerated() {
                            
                            if let dataSrcDict = dObject as? [String: Any],let dataSourceName = dataSrcDict["dataSrcName"] as? String {
                                dataSourceArray.append(dataSourceName)
                            }
                        }
                    }
                }
            }
        }
    }
    
    func setEquipmentsArray() {
        
        let json = getJson(fromFile: "equipments", ofType: "json")
        
        if let dictionary = json as? [String: Any],let eqmntsArray = dictionary["equipments"] as? [Any]{
            
            eqmntsObjArray = eqmntsArray //For passing to next function
            
            //Retrieve Objects
            for (_,objects) in eqmntsArray.enumerated() {
                if let eqpmntDict = objects as? [String: Any],let eqpmntName = eqpmntDict["equipmentName"] as? String {
                    equipmentsArray.append(eqpmntName)
                }
            }
        } else {
            print("Unable to Set Up Array")
        
        }
    }
    
    func getJson(fromFile fileName: String,ofType fileType: String) -> Any {
        
        var returnObject: Any?
        do {
            if let file = Bundle.main.url(forResource: fileName, withExtension: fileType) {
                let data = try Data(contentsOf: file)
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                returnObject = json
            }
        } catch {
            print(error.localizedDescription)
            returnObject = nil
        }
        
        return returnObject ?? "Error"
    }
}

