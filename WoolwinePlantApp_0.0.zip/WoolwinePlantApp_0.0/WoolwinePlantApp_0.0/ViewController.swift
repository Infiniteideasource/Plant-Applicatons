//
//  ViewController.swift
//  WoolwinePlantApp_0.0
//
//  Created by Arun Sreekumar on 25/03/17.
//  Copyright © 2017 Apple Inc. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource {
    
    
    //MARK: Properties
    @IBOutlet weak var equipmentNameLabel: UILabel!
    @IBOutlet weak var equipmentNameTextField: UITextField!
    @IBOutlet weak var equipmentPickerView: UIPickerView!
    
    @IBOutlet weak var dataSourceLabel: UILabel!
    @IBOutlet weak var dataSourceTextField: UITextField!
    @IBOutlet weak var dataSourcePickerView: UIPickerView!

    @IBOutlet weak var parameterTableView: UITableView!
    
    
    
    var equipmentsArray = [String]()
    var dataSourceArray = [String]()
    var eqmntsObjArray = [Any]()
    var dataSourceObjArray = [Any]()
    var parameterArray = [Any]()
    
    var currValueArray = [String]()
    var rowBeingEdited: Int? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Set up the equipments array
        setEquipmentsArray()
                
        self.equipmentPickerView.dataSource = self
        self.equipmentPickerView.delegate = self
        self.equipmentNameTextField.delegate = self
        
        self.dataSourcePickerView.dataSource = self
        self.dataSourcePickerView.delegate = self
        self.dataSourceTextField.delegate = self
        
        
        self.parameterTableView.dataSource = self
        self.parameterTableView.delegate = self
        self.parameterTableView.register(UITableViewCell.self, forCellReuseIdentifier: "defaultCell")
        
        //table view header height
        self.parameterTableView.sectionHeaderHeight = 50
        
        //Hide Secondary picker view
        self.dataSourcePickerView.isHidden = true
        self.dataSourceLabel.isHidden = true
        self.dataSourceTextField.isHidden = true
        
        //Hide the table view
        self.parameterTableView.isHidden = true
    }
    
    //MARK: UIPickerViewDataSource methods
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        var rowCount = 0
        
        if pickerView == equipmentPickerView {
            rowCount = equipmentsArray.count
        }
        
        if pickerView == dataSourcePickerView {
            rowCount = dataSourceArray.count
        }
        
        return rowCount
    }
    
    //MARK: UIPickerViewDelegate methods
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        //resign the first responder status for text field
        self.view.endEditing(true)
        
        if pickerView == equipmentPickerView {
            return equipmentsArray[row]
        }
        if pickerView == dataSourcePickerView {
            return dataSourceArray[row]
        }
        return ""
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        let pickerLabel = UILabel()
        pickerLabel.textColor = UIColor.black
        pickerLabel.font = UIFont.systemFont(ofSize: 38.0)
        pickerLabel.textAlignment = NSTextAlignment.center
        
        if pickerView == equipmentPickerView {
            pickerLabel.text = equipmentsArray[row]
        }
        
        if pickerView == dataSourcePickerView {
            pickerLabel.text = dataSourceArray[row]
        }
        
      return pickerLabel

    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerView == equipmentPickerView {
            
            self.equipmentNameTextField.text = equipmentsArray[row]
            
            //Hide the picker view after setting textfield
            self.equipmentPickerView.isHidden = true
            
            //Set up dataSourceArray for equipment selected
            let equipmentSelected = equipmentsArray[row]
            setDataSourceArray(for: equipmentSelected)
        
            //Reload secondary picker view
            dataSourcePickerView.reloadAllComponents()
            
            //Unhide the secondary views
            self.dataSourcePickerView.isHidden = false
            self.dataSourceLabel.isHidden = false
            self.dataSourceTextField.isHidden = false
        }
        
        if pickerView == dataSourcePickerView {
            self.dataSourceTextField.text = dataSourceArray[row]
            
            //Hiding the picker view after setting the text field
            self.dataSourcePickerView.isHidden = true
            
            //Set up the parameter arrays for equipments & data source selected
            let dataSourceSelected = dataSourceArray[row]
            setParameterArray(for: dataSourceSelected)
            
            //Reload the table view with parameters for equipment & data source selected
            self.parameterTableView.reloadData()
            
            //Unhide the table view
            self.parameterTableView.isHidden = false
            
        }
    }
    
    //MARK: UITextFieldDelegate methods
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        //Set the rowBeingEdited variable for table view textField
        rowBeingEdited = textField.tag
    
        if textField == self.equipmentNameTextField {
            
            //Clear the dataSourceArray & parameter array
            if dataSourceArray.count > 0 {
                dataSourceArray.removeAll()
                parameterArray.removeAll()
                dataSourceObjArray.removeAll()
            }
            
            //Clear Data Source Text Field
            if dataSourceTextField.text != nil {
                dataSourceTextField.text?.removeAll()
            }
            
            //Hide Secondary picker view & table view
            self.dataSourcePickerView.isHidden = true
            self.dataSourceLabel.isHidden = true
            self.dataSourceTextField.isHidden = true
            self.parameterTableView.isHidden = true
            
            //Unhide the picker view when user clicks text field
            self.equipmentPickerView.isHidden = false
            
            //Hide the keyboard
            textField.endEditing(true)
        }
        
        if textField == self.dataSourceTextField {
            
            //Unhide the picker view when user clicks the text field
            self.dataSourcePickerView.isHidden = false
            
            //need a logic to save table view data
            
            //Hide the keyboard
            textField.endEditing(true)
        }
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if parameterTableView.indexPathForSelectedRow != nil {
            
            let row = textField.tag
            var addRow = currValueArray.count
            
            //Add blank records in array if user skips rows in table views
            if row >= currValueArray.count {
                while addRow <= row {
                    currValueArray.append("")
                    addRow = addRow + 1
                }
            }
            
            if let textString = textField.text {
                currValueArray[row] = textString
            }
            
            rowBeingEdited = nil
        }
    }
    
    
    //MARK: UITableViewDataSource Methods
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.parameterArray.count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerCellIdentifier = "HeaderTableViewCell"
        
        guard let headerCell = tableView.dequeueReusableCell(withIdentifier: headerCellIdentifier) as? HeaderTableViewCell else {
            
            fatalError("Error in dequeuing HeaderTableViewCell")
            
        }
        
        let headerView = UIView()
        headerView.addSubview(headerCell)
        headerView.backgroundColor = UIColor.purple
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //let cellIdentifier = "defaultCell"
        let cellIdentifier = "ParameterTableViewCell"
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? ParameterTableViewCell, let parameterDict = parameterArray[indexPath.row] as? [String: String] else {
            fatalError("Error in dequeuing ParameterTableViewCell")
        }
        
        //Setting the cell labels
        cell.paraNameLabel.text = parameterDict["paramName"]
        cell.paraUOMLabel.text = parameterDict["paramUnit"]
        cell.paraMaxValueLabel.text = parameterDict["paramUSL"]
        cell.paraMinValueLabel.text = parameterDict["paramLSL"]
        
        //Setting the textFields for use
        cell.paraCurrValueTextField.text = "" //Clears text for cell re-use
        cell.paraCurrValueTextField.tag = indexPath.row
        cell.paraCurrValueTextField.delegate = self
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print("You selected cell#\(indexPath.row)")
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //MARK: Actions
    
    
    //MARK: Private Methods
    
    func setParameterArray(for dataSource: String) {
        //print("Data Source Selected = \(dataSource)")
        
        //Clear elements in parameter array
        parameterArray.removeAll()
        
        for (_,dsObject) in dataSourceObjArray.enumerated() {
            
            if let dsDict = dsObject as? [String: Any], let dsName = dsDict["dataSrcName"] as? String {
                
                if dsName == dataSource {
                    
                    if let dsParaArray = dsDict["dataSourceParameters"] as? [Any] {
                        
                        parameterArray = dsParaArray //Use this in table view
                        
                    }
                }
            }
        }
    }
    
    func setDataSourceArray(for equipment: String) {
        
        //Clear the elements in dataSourceArray first
        dataSourceArray.removeAll()
        dataSourceObjArray.removeAll()
        
        for (_,object) in eqmntsObjArray.enumerated() {
            
            if let eqDict = object as? [String: Any], let eqName = eqDict["equipmentName"] as? String {
                
                if eqName == equipment {
                    
                    if let dataSrceArray = eqDict["dataSources"] as? [Any] {
                        
                        dataSourceObjArray = dataSrceArray//For using in next function
                        
                        for (_,dObject) in dataSrceArray.enumerated() {
                            
                            if let dataSrcDict = dObject as? [String: Any],let dataSourceName = dataSrcDict["dataSrcName"] as? String {
                                dataSourceArray.append(dataSourceName)
                            }
                        }
                    }
                }
            }
        }
    }
    
    func setEquipmentsArray() {
        
        let json = getJson(fromFile: "equipments", ofType: "json")
        
        if let dictionary = json as? [String: Any],let eqmntsArray = dictionary["equipments"] as? [Any]{
            
            eqmntsObjArray = eqmntsArray //For passing to next function
            
            //Retrieve Objects
            for (_,objects) in eqmntsArray.enumerated() {
                if let eqpmntDict = objects as? [String: Any],let eqpmntName = eqpmntDict["equipmentName"] as? String {
                    equipmentsArray.append(eqpmntName)
                }
            }
        } else {
            print("Unable to Set Up Array")
        
        }
    }
    
    func getJson(fromFile fileName: String,ofType fileType: String) -> Any {
        
        var returnObject: Any?
        do {
            if let file = Bundle.main.url(forResource: fileName, withExtension: fileType) {
                let data = try Data(contentsOf: file)
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                returnObject = json
            }
        } catch {
            print(error.localizedDescription)
            returnObject = nil
        }
        
        return returnObject ?? "Error"
    }
}

