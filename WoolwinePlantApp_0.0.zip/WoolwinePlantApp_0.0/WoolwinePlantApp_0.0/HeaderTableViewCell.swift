//
//  HeaderTableViewCell.swift
//  WoolwinePlantApp_0.0
//
//  Created by Arun Sreekumar on 09/04/17.
//  Copyright © 2017 Apple Inc. All rights reserved.
//

import UIKit

class HeaderTableViewCell: UITableViewCell {
    
    //MARK: Properties
    @IBOutlet weak var hdrParaNameLabel: UILabel!
    @IBOutlet weak var hdrParaCurrValueLabel: UILabel!
    @IBOutlet weak var hdrParaUOMLabel: UILabel!
    @IBOutlet weak var hdrParaMinValueLabel: UILabel!
    @IBOutlet weak var hdrParaMaxValueLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
